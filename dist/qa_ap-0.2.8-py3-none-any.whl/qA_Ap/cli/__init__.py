import sys

def export_frontend():
    print(sys.argv)

def setup_boilerplate():
    print(sys.argv)