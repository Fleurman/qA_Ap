class FileAlreadyExistsError(Exception):
    pass

class WriteInDatabaseError(Exception):
    pass