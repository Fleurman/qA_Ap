def export_frontend(path: str = "test"):
    print(path)

def setup_boilerplate(path: str = "test2"):
    print(path)